#' tasselr.
#'
#' @name tasselr
#' @docType package
#' @importFrom IRanges IntegerList CharacterList
#' @import rhdf5
#' @import methods
#' @useDynLib tasselr
#' @importFrom inline cfunction
#' @importFrom Rcpp sourceCpp
#' @importFrom Biobase samples
NULL


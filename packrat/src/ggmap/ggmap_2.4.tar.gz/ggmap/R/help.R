#' @import ggplot2 proto scales RgoogleMaps png plyr reshape2 grid rjson mapproj jpeg geosphere
#' @docType package
#' @name ggmap
#' @aliases ggmap package-ggmap
NULL